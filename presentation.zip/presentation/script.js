const slides = document.querySelectorAll('.slide');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const progress = document.getElementById('progress');

let currentSlide = 0;

function updateSlides() {
    slides.forEach((slide, index) => {
        slide.classList.remove('active', 'previous');
        if (index === currentSlide) {
            // Force reflow for animations
            slide.style.display = 'none';
            slide.offsetHeight; 
            slide.style.display = 'flex';
            slide.classList.add('active');
        } else if (index < currentSlide) {
            slide.classList.add('previous');
        }
    });

    // Update progress bar
    const progressWidth = ((currentSlide + 1) / slides.length) * 100;
    progress.style.width = `${progressWidth}%`;

    // Manage buttons
    prevBtn.style.opacity = currentSlide === 0 ? '0.3' : '1';
    prevBtn.style.pointerEvents = currentSlide === 0 ? 'none' : 'all';
    
    nextBtn.style.opacity = currentSlide === slides.length - 1 ? '0.3' : '1';
    nextBtn.style.pointerEvents = currentSlide === slides.length - 1 ? 'none' : 'all';
}

nextBtn.addEventListener('click', () => {
    if (currentSlide < slides.length - 1) {
        currentSlide++;
        updateSlides();
    }
});

prevBtn.addEventListener('click', () => {
    if (currentSlide > 0) {
        currentSlide--;
        updateSlides();
    }
});

// Key bindings
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight' || e.key === ' ') {
        if (currentSlide < slides.length - 1) {
            currentSlide++;
            updateSlides();
        }
    } else if (e.key === 'ArrowLeft') {
        if (currentSlide > 0) {
            currentSlide--;
            updateSlides();
        }
    }
});

// Initialize
updateSlides();
